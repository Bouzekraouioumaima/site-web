﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Configuration;

using System.Web.Mail;
using System.Text;
using System.Net;

public partial class inscription : System.Web.UI.Page
{
   string  cn =(@"Data Source=desktop-35blbr5\sqlexpress;Initial Catalog=mawazine;Integrated Security=True ");


    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
  
    protected void Button1_Click(object sender, EventArgs e)
    {

        try
        {
            using (SqlConnection sqlcn = new SqlConnection(cn))
            { 
                sqlcn.Open();
            SqlCommand cm = new SqlCommand("useradd", sqlcn);
            cm.CommandType = CommandType.StoredProcedure;
            cm.Parameters.AddWithValue("@nom", TextBox2.Text.Trim());
            cm.Parameters.AddWithValue("@prenom", TextBox1.Text.Trim());
            cm.Parameters.AddWithValue("@usernom", TextBox3.Text.Trim());
            cm.Parameters.AddWithValue("@adress", TextBox4.Text.Trim());
            cm.Parameters.AddWithValue("@sexe", DropDownList1.Text);
            cm.Parameters.AddWithValue("@passwrd", TextBox5.Text.Trim());
            cm.Parameters.AddWithValue("@cfrmpasswrd", TextBox6.Text.Trim());
            cm.ExecuteNonQuery();
            lblinscrir.Text = "submitted successfuly";
            sqlcn.Close();
               
            }
        }
        catch (Exception ex)
        {
            lblinscrir.Text = ex.Message;
        }
        ////////////////////////////////////////////////////////////////////////////////////////
        ///
        HttpPostedFile postedfil = FileUpload1.PostedFile;
        // get name of the file
        string filename = Path.GetFileName(postedfil.FileName);
        // get extension of the file
        string fileExtension = Path.GetExtension(filename);
        // get the size of file
        int filesize = postedfil.ContentLength;
        if (fileExtension.ToLower() != ".png" && fileExtension.ToLower() != ".jpg" && fileExtension.ToLower() != ".jpeg")
        {
            lblMessage.Text = " only files with .png , .peng  , .jpg , jpeg";
            lblMessage.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            Stream stream = postedfil.InputStream;
            // lire les donnees de type varbinary
            BinaryReader binaryReader = new BinaryReader(stream);
            byte[] bytes = binaryReader.ReadBytes((int)stream.Length);
            using (SqlConnection sqlcn = new SqlConnection(cn))
            {
                sqlcn.Open();
                SqlCommand cmd = new SqlCommand("uploadimage", sqlcn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", filename);
                cmd.Parameters.AddWithValue("@size", filesize);
                cmd.Parameters.AddWithValue("@imagedata", bytes);
                cmd.ExecuteNonQuery();
                sqlcn.Close();
            }
            lblMessage.Text = " file upload";
            lblMessage.ForeColor = System.Drawing.Color.Green;
        }

    }
   

        protected void CustomValidator1_ServerValidate1(object source, ServerValidateEventArgs args)
    {
       
    }

    protected void CustomValidator2_ServerValidate(object source, ServerValidateEventArgs args)
    {

    }
}