﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class contact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    string cn = (@"Data Source=desktop-35blbr5\sqlexpress;Initial Catalog=mawazine;Integrated Security=True");

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection sqlcn = new SqlConnection(cn))
            {
                sqlcn.Open();
                SqlCommand cm = new SqlCommand("contactadd", sqlcn);
                cm.CommandType = CommandType.StoredProcedure;
                cm.Parameters.AddWithValue("@usernom", TextBox1.Text.Trim());
                cm.Parameters.AddWithValue("@adress", TextBox3.Text.Trim());
                cm.Parameters.AddWithValue("@tele", TextBox4.Text.Trim());
                cm.Parameters.AddWithValue("@messag", TextBox5.Text.Trim());
                cm.ExecuteNonQuery();
                Label1.Text = "submitted successfuly";
                sqlcn.Close();

            }
        }
        catch (Exception ex)
        {
            Label1.Text = ex.Message;
        }
    }
}